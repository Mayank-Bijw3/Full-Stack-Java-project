package mayankbijw3.billingSoftware;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BillingSoftwareApplicationTests {

	@Test
	void contextLoads() {
	}

}
